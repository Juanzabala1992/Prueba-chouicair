package Stepdefinitions;

import java.util.concurrent.TimeUnit;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchPage {

	WebDriver driver=null;
	
	@Given("Abrir el buscador")
	public void abrir_el_buscador() {
	    // Write code here that turns the phrase above into concrete actions
	   String projectPath = System.getProperty("user.dir");
	   System.setProperty("webdriver.chrome.driver"+projectPath,"src/test/resources/drivers/chromedriver.exe");
	   driver = new ChromeDriver();
	   driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	   driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
	   
	}

	@And("El usurario busca la pagina")
	public void el_usurario_busca_la_pagina() {
	    // Write code here that turns the phrase above into concrete actions
		driver.navigate().to("https://www.phptravels.net/admin");
		
	}

	@When("El usuario ingresa a la pagina")
	public void el_usuario_ingresa_a_la_pagina() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com"); 
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		driver.findElement(By.name("password")).sendKeys(Keys.ENTER);
	}
	
	@And("El busca la seccion blog")
	public void el_busca_la_seccion_blog() {
		
		driver.findElement(By.xpath("//*[@id=\"social-sidebar-menu\"]/li[14]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"Blog\"]/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div[2]/div[1]/button")).click();
		driver.findElement(By.name("name")).sendKeys("Prueba-chouicair"); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@When("El usuario carga una nueva categoria")
	public void el_usuario_carga_una_nueva_categoria() {
		
		driver.findElement(By.name("translated[vi][name]")).sendKeys("Prueba-chouicair");
		driver.findElement(By.name("translated[ru][name]")).sendKeys("Prueba-chouicair");
		driver.findElement(By.name("translated[ar][name]")).sendKeys("Prueba-chouicair");
		driver.findElement(By.name("translated[fa][name]")).sendKeys("Prueba-chouicair");
		driver.findElement(By.name("translated[tr][name]")).sendKeys("Prueba-chouicair"); 
		driver.findElement(By.name("translated[fr][name]")).sendKeys("Prueba-chouicair"); 
		driver.findElement(By.name("translated[es][name]")).sendKeys("Prueba-chouicair"); 
		driver.findElement(By.name("translated[de][name]")).sendKeys("Prueba-chouicair"); 
		driver.findElement(By.xpath("//*[@id=\"ADD_BLOG_CAT\"]/div[2]/div/form/div[3]/button[2]")).click();
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);		
				
	}
	
	@When("El busca la seccion categoria")
	public void El_busca_la_seccion_categoria() { 
		driver.findElement(By.xpath("//*[@id=\"social-sidebar-menu\"]/li[14]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"Blog\"]/li[1]/a")).click();
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/form/button")).click();
		
	}
	
	@Then("El carga el post")
	public void El_carga_el_post() {
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//*[@id=\"GENERAL\"]/div[1]/div[1]/div/input")).sendKeys("Prueba Chouicair"); 
		driver.findElement(By.name("slug")).sendKeys("Prueba Chouicair"); 
				
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
			    
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div[2]/div/div/div[2]/div[2]/div/select")).sendKeys("Prueba");//descripcion
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div[2]/div/div/div[2]/div[2]/div/select")).sendKeys("Prueba");
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"cke_1_contents\"]/iframe") ).click();
		driver.findElement(By.xpath("//*[@id=\"cke_1_contents\"]/iframe") ).sendKeys("Esto es una prueba ");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"cke_1_contents\"]/iframe") ).sendKeys("Esto es una prueba ");
		driver.findElement(By.xpath("//*[@id=\"cke_1_contents\"]/iframe") ).sendKeys("Esto es una prueba ");
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div[1]/div/div[2]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"cke_1_contents\"]/iframe") ).sendKeys("Esto es una prueba ");
		driver.findElement(By.xpath("//*[@id=\"cke_1_contents\"]/iframe") ).sendKeys("Esto es una prueba ");
		
	}
}
